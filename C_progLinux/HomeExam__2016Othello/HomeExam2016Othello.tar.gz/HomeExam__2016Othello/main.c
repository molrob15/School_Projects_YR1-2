#include <stdio.h>
#include "game.h"

/**
 * The main function is just used 
 * to call the main game loop in 
 * function Othello.
 *	
 * @author molrob15 <-- Robert Mattias Molin
 * 2016.12.13	
 */


int main()
{

	Othello();
	
	return 0;
}
