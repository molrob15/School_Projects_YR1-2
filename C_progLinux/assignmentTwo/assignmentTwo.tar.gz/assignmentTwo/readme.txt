 To run program from command line, enter executable filename (./main) followed by _width_height_ directory name.
 Example: ./main 3 2 wolf 

 In my assignment I've used nested for loop constructs to iterate through the files in the two directories 
 mickey and wolf, in order to get 30 chars and read 30 lines from the files.
 The readChar function might not be necessary, but the thought behind it was to make sure the function kept reading 30 chars from line even if a 'n\' char would appear. 
 My functions are decared in header file asciiArt.h for simplicity.

 @molrob15 
  
