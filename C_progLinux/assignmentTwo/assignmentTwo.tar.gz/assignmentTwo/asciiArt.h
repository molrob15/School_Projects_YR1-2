

/**
* Function declarations: createAscii, 
* readChar
*/
void createAscii(int fileHeight, int fileWidth, char* fileDescriptor);

char readChar(FILE *fp); 
 

